from cinematica_robots import cinematica
import matplotlib.pyplot as plt
import numpy as np
import math
from matplotlib.widgets import Slider

grafica = cinematica()
grafica.configuracion_grafica_x(-15, 15, -15, 15, -5, 15, "Robot 8 RRPR")
cinematica.robot_8(grafica, (0, 3, 0, 0), (90, 3, 0, -45), (90, 0, 3, 0), (0, 2 + 3, 0, 0), (0, 2, 0, 0))


def cinematica_inversa(x, y, z):
    # siendo los eslabones
    l3 = 3
    l4 = 3
    l5 = 3
    l6 = 2
    l7 = 2
    val = math.sqrt(x ** 2 + y ** 2 + (z - l3 - l4) ** 2 - l5 ** 2) - l6 - l7
    if val > 3:
        val = 3
    elif val < 0:
        val = 0
    A = l7 + l6 + val
    B = l5
    a = A
    b = - B
    alpha_2 = math.asin(math.sqrt(x ** 2 + y ** 2) / math.sqrt(a ** 2 + b ** 2)) - math.atan2(b, a)
    theta_2 = math.asin(x / ((l7 + l6 + val) * math.sin(alpha_2) - l5 * math.cos(alpha_2)))
    theta_2 = round((theta_2 * 180) / np.pi, 2)
    alpha_2 = round((alpha_2 * 180) / np.pi, 2)
    print(f"val: {val}")
    print(f"alpha2= {alpha_2}°")
    print(f"theta2= {theta_2}°")
    return theta_2, alpha_2, val


def actualizacion_juntas(val):
    grafica.grafica.cla()

    theta_5 = sld_theta_5.val
    x = sld_x.val
    y = sld_y.val
    z = sld_z.val
    theta_2, alpha_2, val = cinematica_inversa(x, y, z)

    grafica.configuracion_grafica_x(-15, 15, -15, 15, -5, 15, "Robot 8 RRPR")

    matriz_TH = cinematica.robot_8(grafica, (theta_2, 3, 0, 0), (0, 3, 0, alpha_2), (90, 0, 3, 0), (0, 2 + val, 0, 0),
                                   (theta_5, 2, 0, 0))
    sld_x.eventson = False
    sld_y.eventson = False
    sld_z.eventson = False
    sld_x.set_val(matriz_TH[0, 3])
    sld_y.set_val(matriz_TH[1, 3])
    sld_z.set_val(matriz_TH[2, 3])
    sld_x.eventson = True
    sld_y.eventson = True
    sld_z.eventson = True

    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1
    plt.draw()
    plt.pause(1e-6)


def actualizacion_juntas1(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-15, 15, -15, 15, -5, 15, "Robot 8 RRPR")

    theta_5 = sld_theta_5.val
    x = sld_x.val
    y = sld_y.val
    z = sld_z.val
    theta_2, alpha_2, val = cinematica_inversa(x, y, z)

    matriz_TH = cinematica.robot_8(grafica, (theta_2, 3, 0, 0), (0, 3, 0, alpha_2), (90, 0, 3, 0), (0, 2 + val, 0, 0),
                                   (theta_5, 2, 0, 0))
    sld_y.eventson = False
    sld_z.eventson = False
    sld_y.set_val(matriz_TH[1, 3])
    sld_z.set_val(matriz_TH[2, 3])
    sld_y.eventson = True
    sld_z.eventson = True
    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1

    plt.draw()
    plt.pause(1e-6)


def actualizacion_juntas2(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-15, 15, -15, 15, -5, 15, "Robot 8 RRPR")

    theta_5 = sld_theta_5.val
    x = sld_x.val
    y = sld_y.val
    z = sld_z.val
    theta_2, alpha_2, val = cinematica_inversa(x, y, z)

    matriz_TH = cinematica.robot_8(grafica, (theta_2, 3, 0, 0), (0, 3, 0, alpha_2), (90, 0, 3, 0), (0, 2 + val, 0, 0),
                                   (theta_5, 2, 0, 0))
    sld_x.eventson = False
    sld_z.eventson = False
    sld_x.set_val(matriz_TH[0, 3])
    sld_z.set_val(matriz_TH[2, 3])
    sld_x.eventson = True
    sld_z.eventson = True
    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0

        i += 1

    plt.draw()
    plt.pause(1e-6)


def actualizacion_juntas3(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-15, 15, -15, 15, -5, 15, "Robot 8 RRPR")

    theta_5 = sld_theta_5.val
    x = sld_x.val
    y = sld_y.val
    z = sld_z.val
    theta_2, alpha_2, val = cinematica_inversa(x, y, z)

    matriz_TH = cinematica.robot_8(grafica, (theta_2, 3, 0, 0), (0, 3, 0, alpha_2), (90, 0, 3, 0), (0, 2 + val, 0, 0),
                                   (theta_5, 2, 0, 0))
    sld_x.eventson = False
    sld_y.eventson = False
    sld_x.set_val(matriz_TH[0, 3])
    sld_y.set_val(matriz_TH[1, 3])
    sld_x.eventson = True
    sld_y.eventson = True
    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1

    plt.draw()
    plt.pause(1e-6)


# Agregamos slidersbar para mover los angulos del robot
ax1 = plt.axes([0.2, 0.07, 0.65, 0.03])
ax2 = plt.axes([0.2, 0.05, 0.65, 0.03])
ax3 = plt.axes([0.2, 0.03, 0.65, 0.03])
ax4 = plt.axes([0.2, 0.01, 0.65, 0.03])

Matriz_TH = cinematica.robot_8(grafica, (0, 3, 0, 0), (90, 3, 0, -45), (90, 0, 3, 0), (0, 2 + 3, 0, 0), (0, 2, 0, 0))
tabla = plt.table(cellText=np.round(Matriz_TH, 3), bbox=[0.9, 15, 0.3, 4.5], loc='center')
tabla.auto_set_font_size(False)
tabla.set_fontsize(8)

sld_x = Slider(ax1, r"$x$", -10, 10, valinit=-7.071)
sld_y = Slider(ax2, r"$y$", -10, 10, valinit=0)
sld_z = Slider(ax3, r"$z$", -10, 15, valinit=8.828)
sld_theta_5 = Slider(ax4, r"$\theta_5$", 0, 180, valinit=0)

sld_x.on_changed(actualizacion_juntas1)
sld_y.on_changed(actualizacion_juntas2)
sld_z.on_changed(actualizacion_juntas3)
sld_theta_5.on_changed(actualizacion_juntas)

plt.show()
