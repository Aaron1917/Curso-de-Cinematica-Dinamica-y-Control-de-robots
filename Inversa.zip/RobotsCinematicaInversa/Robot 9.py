from cinematica_robots import cinematica
import matplotlib.pyplot as plt
import numpy as np
import math
from matplotlib.widgets import Slider

grafica = cinematica()
grafica.configuracion_grafica_x(-15, 15, -15, 15, -10, 1, "Robot 9")
cinematica.robot_9(grafica, (0, -3, 0, 0), (90, -3, 0, 90), (0, 2, 0, 0), (0, 1, 0, 0), (90, 2, 0, 0))


def cinematica_inversa(x, y):
    # siendo los eslabones
    l3 = -3
    l4 = -3
    l5 = 2
    l6 = 1
    l7 = 2
    val = math.sqrt(x ** 2 + y ** 2) - l6 - l7 - l5
    if val >= 5:
        val = 5
    elif val <= 0:
        val = 0

    A = l7 + l6 + val + l5

    theta_2 = math.asin(x / A)
    theta_2 = round((theta_2 * 180) / np.pi, 4)

    print(f"val: {val}")
    print(f"theta2= {theta_2}°")

    return theta_2, val


def actualizacion_juntas(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-15, 15, -15, 15, -10, 1, "Robot 9")
    x = sld_x.val
    y = sld_y.val
    # z = sld_z.val
    theta_2, val = cinematica_inversa(x, y)
    theta_5 = sld_theta_5.val

    matriz_TH = cinematica.robot_9(grafica, (0, -3, 0, 0), (theta_2, -3, 0, 90), (0, 2, 0, 0), (0, val, 0, 0),
                                   (theta_5, 2, 0, 0))
    sld_x.eventson = False
    sld_y.eventson = False
    #sld_z.eventson = False
    sld_x.set_val(matriz_TH[0, 3])
    sld_y.set_val(matriz_TH[1, 3])
    #sld_z.set_val(matriz_TH[2, 3])
    sld_x.eventson = True
    sld_y.eventson = True
    #sld_z.eventson = True

    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1
    plt.draw()
    plt.pause(1e-6)


def actualizacion_juntas1(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-15, 15, -15, 15, -10, 1, "Robot 9")

    x = sld_x.val
    y = sld_y.val
    # z = sld_z.val
    theta_2, val = cinematica_inversa(x, y)
    theta_5 = sld_theta_5.val

    matriz_TH = cinematica.robot_9(grafica, (0, -3, 0, 0), (theta_2, -3, 0, 90), (0, 2, 0, 0), (0, val, 0, 0),
                                   (theta_5, 2, 0, 0))
    sld_y.eventson = False
    # sld_z.eventson = False
    sld_y.set_val(matriz_TH[1, 3])
    # sld_z.set_val(matriz_TH[2, 3])
    sld_y.eventson = True
    # sld_z.eventson = True
    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1

    plt.draw()
    plt.pause(1e-6)


def actualizacion_juntas2(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-15, 15, -15, 15, -10, 1, "Robot 9")

    x = sld_x.val
    y = sld_y.val
    # z = sld_z.val
    theta_2, val = cinematica_inversa(x, y)
    theta_5 = sld_theta_5.val

    matriz_TH = cinematica.robot_9(grafica, (0, -3, 0, 0), (theta_2, -3, 0, 90), (0, 2, 0, 0), (0, val, 0, 0),
                                   (theta_5, 2, 0, 0))
    sld_x.eventson = False
    # sld_z.eventson = False
    sld_x.set_val(matriz_TH[0, 3])
    # sld_z.set_val(matriz_TH[2, 3])
    sld_x.eventson = True
    # sld_z.eventson = True
    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0

        i += 1

    plt.draw()
    plt.pause(1e-6)


# Agregamos slidersbar para mover los angulos del robot
ax1 = plt.axes([0.2, 0.1, 0.65, 0.03])
ax2 = plt.axes([0.2, 0.07, 0.65, 0.03])
ax3 = plt.axes([0.2, 0.04, 0.65, 0.03])

Matriz_TH = cinematica.robot_9(grafica, (0, -3, 0, 0), (90, -3, 0, 90), (0, 2, 0, 0), (0, 1, 0, 0), (90, 2, 0, 0))
tabla = plt.table(cellText=np.round(Matriz_TH, 3), bbox=[0.9, 15, 0.3, 4.5], loc='center')
tabla.auto_set_font_size(False)
tabla.set_fontsize(8)

sld_x = Slider(ax1, r"$x$", -11, 11, valinit=7)
sld_y = Slider(ax2, r"$y$", -11, 11, valinit=-0)
sld_theta_5 = Slider(ax3, r"$\theta_5$", 0, 360, valinit=90)

sld_x.on_changed(actualizacion_juntas1)
sld_y.on_changed(actualizacion_juntas2)
sld_theta_5.on_changed(actualizacion_juntas)

plt.show()
