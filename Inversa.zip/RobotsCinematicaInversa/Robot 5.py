import math
import numpy as np
from cinematica_robots import cinematica
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider

grafica = cinematica()
grafica.configuracion_grafica_z(-10, 10, -10, 10, -1, 10, "Robot 5")
cinematica.robot_5(grafica, (0, 0, 3, 0), (45, 0, 3 + 1, 0), (45, 0, 3, 0))


def cinematica_inversa(x, y):
    # eslabones
    l1 = 3
    l2 = 3 + 1
    l3 = 3

    A = ((x - l1) ** 2 + y ** 2 - l2 ** 2 - l3 ** 2)/(2 * l2 * l3)
    print(f"A vale: {A}")
    theta_3 = math.atan2(math.sqrt(1 - A ** 2), A)
    # theta_3 = math.acos(A)
    theta_2 = math.atan2(y, x - l1) - math.atan2(l3 * math.sin(theta_3), l2  + l3 * math.cos(theta_3))
    theta_2 = round((theta_2 * 180) / np.pi, 1)
    theta_3 = round((theta_3 * 180) / np.pi, 1)
    print(f"theta2: {theta_2}, theta3: {theta_3}")
    return theta_2, theta_3


def actualizacion_juntas(val):
    grafica.grafica.cla()

    theta_2 = sld_theta_2.val
    a2 = sld_a2.val
    theta_3 = sld_theta_3.val

    grafica.configuracion_grafica_z(-10, 10, -10, 10, -1, 10, "Robot 5")
    cinematica.robot_5(grafica, (0, 0, 3, 0), (theta_2, 0, 3 + a2, 0), (theta_3, 0, 3, 0))

    plt.draw()
    plt.pause(1e-5)


def actualizacion_juntas1(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_z(-10, 10, -10, 10, -1, 10, "Robot 5")

    a2 = 1
    x = sld_x.val
    y = sld_y.val
    #z = sld_z.val

    theta_2, theta_3 =cinematica_inversa(x, y)

    matriz_TH = cinematica.robot_5(grafica, (0, 0, 3, 0), (theta_2, 0, 3 + a2, 0), (theta_3, 0, 3, 0))


    # sld_x.eventson = False
    sld_y.eventson = False
    #sld_z.eventson = False
    # sld_x.set_val(matriz_TH[0, 3])
    sld_y.set_val(matriz_TH[1, 3])
    #sld_z.set_val(matriz_TH[2, 3])
    # sld_x.eventson = True
    sld_y.eventson = True
    #sld_z.eventson = True

    i, j = 0, 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1

    plt.draw()
    plt.pause(1e-5)


def actualizacion_juntas2(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_z(-10, 10, -10, 10, -1, 10, "Robot 5")

    a2 = 1
    x = sld_x.val
    y = sld_y.val
    # z = sld_z.val

    theta_2, theta_3 = cinematica_inversa(x, y)

    matriz_TH = cinematica.robot_5(grafica, (0, 0, 3, 0), (theta_2, 0, 3 + a2, 0), (theta_3, 0, 3, 0))

    sld_x.eventson = False
    # sld_y.eventson = False
    # sld_z.eventson = False
    sld_x.set_val(matriz_TH[0, 3])
    # sld_y.set_val(matriz_TH[1, 3])
    # sld_z.set_val(matriz_TH[2, 3])
    sld_x.eventson = True
    # sld_y.eventson = True
    # sld_z.eventson = True

    i, j = 0, 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1

    plt.draw()
    plt.pause(1e-5)


# Agregamos slidersbar para mover los angulos del robot
ax1 = plt.axes([0.2, 0.01, 0.65, 0.03])
ax2 = plt.axes([0.2, 0.03, 0.65, 0.03])

Matriz_TH = cinematica.robot_5(grafica, (0, 0, 3, 0), (45, 0, 3 + 1, 0), (45, 0, 3, 0))
tabla = plt.table(cellText=np.round(Matriz_TH, 3), bbox=[0.9, 15, 0.3, 4.5], loc='center')
tabla.auto_set_font_size(False)
tabla.set_fontsize(8)

sld_x = Slider(ax1, r'$x$', 3, 8, valinit=5.82)
sld_y = Slider(ax2, r'$y$', 0, 5, valinit=3.82)

sld_x.on_changed(actualizacion_juntas1)
sld_y.on_changed(actualizacion_juntas2)

plt.show()