import math
import numpy as np
from cinematica_robots import cinematica
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider

grafica = cinematica()
grafica.configuracion_grafica_x(-10, 10, -10, 10, -1, 10, "Robot 1")
cinematica.robot_1(grafica, (0, 3, 0, 0), (45, 3 + 2, 1, 90), (0, 3 + 2, 0, 0), (-90, 0, 0, 0))


def cinematica_inversa(x, y, z):
    #eslabones
    l3 = 3
    l4 = 3
    l5 = 1
    l6 = 3

    v1 = z - l4 - l3    # z <= l4+l3
    v2 = -l6 + math.sqrt(x ** 2 + y ** 2 - l5 ** 2)
    if 0 < v2:
        v2 = 0
    theta_2 = math.asin(x/math.sqrt(x **2 + y ** 2))  - math.atan2(l5, l6+v2)
    theta_2 = round((theta_2 * 180) / np.pi, 2)
    return theta_2, v1, v2

def actualizacion_juntas(val):
    grafica.grafica.cla()

    theta_2 = sld_angulo_1.val
    d2 = sld_d2.val
    d3 = sld_d3.val

    grafica.configuracion_grafica_x(-10, 10, -10, 10, -1, 10, "Robot 1")
    cinematica.robot_1(grafica, (0, 3, 0, 0), (theta_2, 3 + d2, 1, 90), (0, 3 + d3, 0, 0), (-90, 0, 0, 0))

    plt.draw()
    plt.pause(1e-5)


def actualizacion_juntas1(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-10, 10, -10, 10, -1, 10, "Robot 1")

    x = sld_x.val
    y = sld_y.val
    z = sld_z.val

    theta_2, d2, d3 =cinematica_inversa(x, y, z)

    matriz_TH = cinematica.robot_1(grafica, (0, 3, 0, 0), (theta_2, 3 + d2, 1, 90), (0, 3 + d3, 0, 0), (-90, 0, 0, 0))

    print(matriz_TH)

    # sld_x.eventson = False
    sld_y.eventson = False
    sld_z.eventson = False
    # sld_x.set_val(matriz_TH[0, 3])
    sld_y.set_val(matriz_TH[1, 3])
    sld_z.set_val(matriz_TH[2, 3])
    # sld_x.eventson = True
    sld_y.eventson = True
    sld_z.eventson = True

    i, j = 0, 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1

    plt.draw()
    plt.pause(1e-5)

def actualizacion_juntas2(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-10, 10, -10, 10, -1, 10, "Robot 1")

    x = sld_x.val
    y = sld_y.val
    z = sld_z.val

    theta_2, d2, d3 = cinematica_inversa(x, y, z)

    matriz_TH = cinematica.robot_1(grafica, (0, 3, 0, 0), (theta_2, 3 + d2, 1, 90), (0, 3 + d3, 0, 0),
                                   (-90, 0, 0, 0))

    print(matriz_TH)

    sld_x.eventson = False
    # sld_y.eventson = False
    sld_z.eventson = False
    sld_x.set_val(matriz_TH[0, 3])
    # sld_y.set_val(matriz_TH[1, 3])
    sld_z.set_val(matriz_TH[2, 3])
    sld_x.eventson = True
    # sld_y.eventson = True
    sld_z.eventson = True

    i, j = 0, 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1

    plt.draw()
    plt.pause(1e-5)


def actualizacion_juntas3(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-10, 10, -10, 10, -1, 10, "Robot 1")

    x = sld_x.val
    y = sld_y.val
    z = sld_z.val

    theta_2, d2, d3 =cinematica_inversa(x, y, z)

    matriz_TH = cinematica.robot_1(grafica, (0, 3, 0, 0), (theta_2, 3 + d2, 1, 90), (0, 3 + d3, 0, 0), (-90, 0, 0, 0))

    print(matriz_TH)

    sld_x.eventson = False
    sld_y.eventson = False
    #sld_z.eventson = False
    sld_x.set_val(matriz_TH[0, 3])
    sld_y.set_val(matriz_TH[1, 3])
    #sld_z.set_val(matriz_TH[2, 3])
    sld_x.eventson = True
    sld_y.eventson = True
    #sld_z.eventson = True

    i, j = 0, 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1

    plt.draw()
    plt.pause(1e-5)

# Agregamos slidersbar para mover los angulos del robot
ax1 = plt.axes([0.2, 0.01, 0.65, 0.03])
ax2 = plt.axes([0.2, 0.03, 0.65, 0.03])
ax3 = plt.axes([0.2, 0.05, 0.65, 0.03])

Matriz_TH = cinematica.robot_1(grafica, (0, 3, 0, 0), (45, 3 + 2, 1, 90), (0, 3 + 2, 0, 0), (-90, 0, 0, 0))
tabla = plt.table(cellText=np.round(Matriz_TH, 3), bbox=[0.9, 15, 0.3, 4.5], loc='center')
tabla.auto_set_font_size(False)
tabla.set_fontsize(8)

sld_x = Slider(ax1, r'$x$', -7, 7, valinit=4.24)
sld_y = Slider(ax2, r'$y$', -7, 7, valinit=-2.82)
sld_z = Slider(ax3, r'$z$', 6, 9, valinit=8)

sld_x.on_changed(actualizacion_juntas1)
sld_y.on_changed(actualizacion_juntas2)
sld_z.on_changed(actualizacion_juntas3)

plt.show()
