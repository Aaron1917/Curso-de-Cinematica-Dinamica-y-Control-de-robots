from cinematica_robots import cinematica
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider
import math
import numpy as np

# Eslabones
l3 = 3
l4 = 2
l5 = 4
l6 = 1
l7 = 4
l8 = 2

grafica = cinematica()
grafica.configuracion_grafica_x(-10, 10, -10, 10, -10, 10, "Robot 6")
cinematica.robot_6(grafica, (45, l3 + l4, 0, 0), (90, 0, l5, 0), (90, 0, l7, 0), (90, l6, 0, 0), (0, l8, 0, 0))


def cinematica_inversa1(x, y):
    a = l7
    b = l5
    theta_1 = math.asin(x / (math.sqrt(a ** 2 + b ** 2))) - math.atan2(b, a)
    theta_1 = round((theta_1 * 180) / np.pi, 2)
    return theta_1


def cinematica_inversa2(x, y):
    b = l7
    a = l5
    theta_1 = math.asin(y / (math.sqrt(a ** 2 + b ** 2))) - math.atan2(b, a)
    theta_1 = round((theta_1 * 180) / np.pi, 2)
    return theta_1


def actualizacion_juntas1(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-10, 10, -10, 10, -10, 10, "Robot 6")

    x = sld_x.val
    y = sld_y.val
    theta_1 = cinematica_inversa1(x, y)

    matriz_TH = cinematica.robot_6(grafica, (theta_1, l3 + l4, 0, 0), (90, 0, l5, 0), (90, 0, l7, 0), (90, l6, 0, 0),
                                   (0, l8, 0, 0))
    sld_y.eventson = False
    sld_y.set_val(matriz_TH[1, 3])
    sld_y.eventson = True
    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1

    plt.draw()
    plt.pause(1e-6)


def actualizacion_juntas2(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-10, 10, -10, 10, -10, 10, "Robot 6")
    x = sld_x.val
    y = sld_y.val
    theta_1 = cinematica_inversa2(x, y)

    matriz_TH = cinematica.robot_6(grafica, (theta_1, l3 + l4, 0, 0), (90, 0, l5, 0), (90, 0, l7, 0), (90, l6, 0, 0),
                                   (0, l8, 0, 0))
    sld_x.eventson = False
    sld_x.set_val(matriz_TH[0, 3])
    sld_x.eventson = True
    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0

        i += 1

    plt.draw()
    plt.pause(1e-6)


# Agregamos slidersbar x, y
ax1 = plt.axes([0.2, 0.1, 0.65, 0.03])
ax2 = plt.axes([0.2, 0.07, 0.65, 0.03])

Matriz_TH = cinematica.robot_6(grafica, (45, l3 + l4, 0, 0), (90, 0, l5, 0), (90, 0, l7, 0), (90, l6, 0, 0),
                               (0, l8, 0, 0))
tabla = plt.table(cellText=np.round(Matriz_TH, 3), bbox=[0.9, 15, 0.3, 4.5], loc='center')
tabla.auto_set_font_size(False)
tabla.set_fontsize(8)

sld_x = Slider(ax1, r"$x$", -5.7, 5.7, valinit=-5.65)
sld_y = Slider(ax2, r"$y$", -5.7, 5.7, valinit=0)

sld_x.on_changed(actualizacion_juntas1)
sld_y.on_changed(actualizacion_juntas2)

plt.show()
