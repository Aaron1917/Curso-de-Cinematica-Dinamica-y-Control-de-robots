from cinematica_robots import cinematica
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider
import math
import numpy as np

grafica = cinematica()
grafica.configuracion_grafica_x(-10, 10, -10, 10, -1, 15, "Robot 10")
cinematica.robot_10(grafica, (45, 7+1, 0, -90), (0, 3, 0, 45), (0, 3, 0, 0), (0, 0,0, 0))


def cinematica_inversa(x, y, z):
    # siendo los eslabones
    l1 = 7
    l2 = 3
    l3 = 2

    #
    theta_1 = math.atan2(y, x)
    r = math.sqrt(x ** 2 + y ** 2)
    # alpha_2 = math.atan2(math.sqrt(1 - ((r - l2) / l3) ** 2), (r - l2) / l3)
    # alpha_2 = math.acos((r - l2) / l3)
    #alpha_2 = math.acos((x + l2 * math.sin(theta_1))/(-l3 * math.sin(theta_1)))
    alpha_2 = math.acos((r - l2)/ l3)
    v = z - l1 - l3 * math.sin(alpha_2)
    if 0 >= v:
        v = 0
    theta_1 = round((theta_1 * 180)/ np.pi,2)
    alpha_2 = round((alpha_2 * 180) / np.pi, 2)

    print(f"theta_1: {theta_1}, alpha_2: {alpha_2}, v: {v}")
    return theta_1, alpha_2, v



def actualizacion_juntas1(val):

    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-10, 10, -10, 10, -1, 15, "Robot 10")

    x = sld_x.val
    y = sld_y.val
    z = sld_z.val
    theta_1, theta_3, var1 = cinematica_inversa(x, y, z)
    
    matriz_TH = cinematica.robot_10(grafica, (theta_1, var1, 0, 0), (0, 0, 5, 90), (theta_3, 0, 5, 0), (0, 0, 2, 0))
    # sld_y.eventson = False
    # sld_z.eventson = False
    # sld_y.set_val(matriz_TH[1, 3])
    # sld_z.set_val(matriz_TH[2, 3])
    # sld_y.eventson = True
    # sld_z.eventson = True
    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1

    plt.draw()
    plt.pause(1e-6)


def actualizacion_juntas2(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-10, 10, -10, 10, -1, 15, "Robot 10")
    x = sld_x.val
    y = sld_y.val
    z = sld_z.val
    theta_1,theta_3, var1 = cinematica_inversa(x, y, z)
    
    matriz_TH = cinematica.robot_10(grafica, (theta_1, var1, 0, 0), (0, 0, 5, 90), (theta_3, 0, 5, 0), (0, 0, 2, 0))
    # sld_x.eventson = False
    # sld_z.eventson = False
    # sld_x.set_val(matriz_TH[0, 3])
    # sld_z.set_val(matriz_TH[2, 3])
    # sld_x.eventson = True
    # sld_z.eventson = True
    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0

        i += 1

    plt.draw()
    plt.pause(1e-6)


def actualizacion_juntas3(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-10, 10, -10, 10, -1, 15, "Robot 10")
    
    x = sld_x.val
    y = sld_y.val
    z = sld_z.val
    theta_1,theta_3, var1 = cinematica_inversa(x, y, z)
    
    matriz_TH = cinematica.robot_10(grafica, (theta_1, var1, 0, 0), (0, 0, 5, 90), (theta_3, 0, 5, 0), (0, 0, 2, 0))
    # sld_x.eventson = False
    # sld_y.eventson = False
    # sld_x.set_val(matriz_TH[0, 3])
    # sld_y.set_val(matriz_TH[1, 3])
    # sld_x.eventson = True
    # sld_y.eventson = True
    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1
    
    plt.draw()
    plt.pause(1e-6)

# Agregamos slidersbar para mover los angulos del robot
ax1 = plt.axes([0.2, 0.1, 0.65, 0.03])
ax2 = plt.axes([0.2, 0.07, 0.65, 0.03])
ax3 = plt.axes([0.2, 0.04, 0.65, 0.03])


Matriz_TH = cinematica.robot_10(grafica, (45, 7+1, 0, -90), (0, 3, 0, 45), (0, 3, 0, 0), (0, 0,0, 0))
tabla = plt.table(cellText=np.round(Matriz_TH, 3), bbox=[0.9, 15, 0.3, 4.5], loc='center')
tabla.auto_set_font_size(False)
tabla.set_fontsize(8)

sld_x = Slider(ax1, r"$x$", -6, 6, valinit=-3.62)
sld_y = Slider(ax2, r"$y$", -6, 6, valinit=3.62)
sld_z = Slider(ax3, r"$z$", 1, 15, valinit=10.12)


sld_x.on_changed(actualizacion_juntas1)
sld_y.on_changed(actualizacion_juntas2)
sld_z.on_changed(actualizacion_juntas3)

plt.show()