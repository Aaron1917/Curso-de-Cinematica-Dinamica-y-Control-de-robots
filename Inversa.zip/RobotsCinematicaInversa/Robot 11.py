import math
import numpy as np
from cinematica_robots import cinematica
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider

grafica = cinematica()
grafica.configuracion_grafica_x(-15, 15, -15, 15, -1, 15, "Robot 11")
l1 = 5
l2 = 2
l3 = 2
cinematica.robot_11(grafica, (45, l1, 0, 45 - 90), (0, l2, 0, 45), (0, l3, 0, 0), (0, 0, 0, 0), (90 + 0, 0, 0, 0))


def cinematica_inversa(x, y, z):
    theta_1 = math.atan2(y, x)
    r = math.sqrt(x ** 2 + y ** 2)
    s = z - l1
    A = (r ** 2 + s ** 2 - l2 ** 2 - l3 ** 2) / (2 * l2 * l3)
    # alpha_2 = math.atan2(math.sqrt(1 - A), A)
    alpha_2 = math.acos(A)
    alpha_1 = math.atan2(s, r) - math.atan2(l3 * math.sin(alpha_2), l2 + l3 * math.cos(alpha_2))

    theta_1 = round((theta_1 * 180) / np.pi, 1)
    alpha_2 = round((alpha_2 * 180) / np.pi, 1)
    alpha_1 = round((alpha_1 * 180) / np.pi, 1)
    print(f"T1 = {theta_1}, A1 = {alpha_1}, A2 = {alpha_2}")
    return theta_1, alpha_1, alpha_2


def actualizacion_juntas(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-15, 15, -15, 15, -1, 15, "Robot 11")

    x = sld_x.val
    y = sld_y.val
    z = sld_z.val

    theta_1, alpha_1, alpha_2 = cinematica_inversa(x, y, z)

    alpha_4 = sld_alpha_4.val
    theta_5 = sld_theta_5.val

    matriz_TH = cinematica.robot_11(grafica, (theta_1, l1, 0, alpha_1 - 90), (0, l2, 0, alpha_2), (0, l3, 0, 0),
                                    (1, 0, 0, alpha_4),
                                    (90 + theta_5, 0, 0, 0))

    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1

    plt.draw()
    plt.pause(1e-5)


def actualizacion_juntas1(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-15, 15, -15, 15, -1, 15, "Robot 11")

    x = sld_x.val
    y = sld_y.val
    z = sld_z.val

    theta_1, alpha_1, alpha_2 = cinematica_inversa(x, y, z)

    alpha_4 = sld_alpha_4.val
    theta_5 = sld_theta_5.val

    matriz_TH = cinematica.robot_11(grafica, (theta_1, l1, 0, alpha_1 - 90), (0, l2, 0, alpha_2), (0, l3, 0, 0),
                                    (1, 0, 0, alpha_4),
                                    (90 + theta_5, 0, 0, 0))

    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1

    plt.draw()
    plt.pause(1e-5)


def actualizacion_juntas2(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-15, 15, -15, 15, -1, 15, "Robot 11")

    x = sld_x.val
    y = sld_y.val
    z = sld_z.val

    theta_1, alpha_1, alpha_2 = cinematica_inversa(x, y, z)

    alpha_4 = sld_alpha_4.val
    theta_5 = sld_theta_5.val

    matriz_TH = cinematica.robot_11(grafica, (theta_1, l1, 0, alpha_1 - 90), (0, l2, 0, alpha_2), (0, l3, 0, 0),
                                    (1, 0, 0, alpha_4),
                                    (90 + theta_5, 0, 0, 0))

    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1

    plt.draw()
    plt.pause(1e-5)


def actualizacion_juntas3(val):
    grafica.grafica.cla()
    grafica.configuracion_grafica_x(-15, 15, -15, 15, -1, 15, "Robot 11")

    x = sld_x.val
    y = sld_y.val
    z = sld_z.val

    theta_1, alpha_1, alpha_2 = cinematica_inversa(x, y, z)

    alpha_4 = sld_alpha_4.val
    theta_5 = sld_theta_5.val

    matriz_TH = cinematica.robot_11(grafica, (theta_1, l1, 0, alpha_1 - 90), (0, l2, 0, alpha_2), (0, l3, 0, 0),
                                    (1, 0, 0, alpha_4),
                                    (90 + theta_5, 0, 0, 0))

    i = 0
    j = 0
    while i < 4:
        while j < 4:
            tabla._cells[(i, j)]._text.set_text(np.round(matriz_TH[i, j], 2))
            j += 1
        j = 0
        i += 1

    plt.draw()
    plt.pause(1e-5)


# Agregamos slidersbar para mover los angulos del robot
ax1 = plt.axes([0.2, 0.01, 0.65, 0.03])
ax2 = plt.axes([0.2, 0.05, 0.65, 0.03])
ax3 = plt.axes([0.2, 0.1, 0.65, 0.03])
ax4 = plt.axes([0.2, 0.15, 0.65, 0.03])
ax5 = plt.axes([0.2, 0.2, 0.65, 0.03])

Matriz_TH = cinematica.robot_11(grafica, (45, l1, 0, 45 - 90), (0, l2, 0, 45), (0, l3, 0, 0), (0, 0, 0, 0),
                                (90 + 0, 0, 0, 0))
tabla = plt.table(cellText=np.round(Matriz_TH, 3), bbox=[0.9, 15, 0.3, 4.5], loc='center')
tabla.auto_set_font_size(False)
tabla.set_fontsize(8)

sld_x = Slider(ax1, r"$x$", -4, 4, valinit=2.41)
sld_y = Slider(ax2, r"$y$", -4, 4, valinit=-2.41)
sld_z = Slider(ax3, r"$z$", 1, 9, valinit=6.41)
sld_alpha_4 = Slider(ax4, r"$\alpha_4$", -180, 180, valinit=0)
sld_theta_5 = Slider(ax5, r"$\theta_5$", -180, 180, valinit=0)

sld_x.on_changed(actualizacion_juntas1)
sld_y.on_changed(actualizacion_juntas2)
sld_z.on_changed(actualizacion_juntas3)
sld_alpha_4.on_changed(actualizacion_juntas)
sld_theta_5.on_changed(actualizacion_juntas)

plt.show()
